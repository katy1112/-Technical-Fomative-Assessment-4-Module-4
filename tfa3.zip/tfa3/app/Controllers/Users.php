<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();

        $users = $userModel->findAll();

        return view('users/index', [
            'users' => $users
        ]);
    }

    public function new()
    {
        return view('users/new');
    }

    public function create()
    {
        $userModel = new UserModel();

        $rules = [
            'username' => 'required|is_unique[users.username]',
            'full_name' => 'required',
            'email' => 'required|valid_email'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $userModel->insert([
            'username' => $this->request->getPost('username'),
            'full_name' => $this->request->getPost('full_name'),
            'email' => $this->request->getPost('email'),
            'created_at' => date('Y-m-d H:i:s'),
            'avatar' => null
        ]);

        return redirect()->to('/users');
    }

    public function edit($id)
    {
        $userModel = new UserModel();

        $user = $userModel->find($id);

        if (!$user) {
            return redirect()->to('/users');
        }

        return view('users/edit', [
            'user' => $user
        ]);
    }

    public function update($id)
    {
        $userModel = new UserModel();

        $user = $userModel->find($id);

        if (!$user) {
            return redirect()->to('/users');
        }

        $rules = [
            'username' => "required|is_unique[users.username,id,{$id}]",
            'full_name' => 'required',
            'email' => 'required|valid_email'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $data = [
            'username' => $this->request->getPost('username'),
            'full_name' => $this->request->getPost('full_name'),
            'email' => $this->request->getPost('email')
        ];

        /*
         * Avatar upload
         */
        $avatar = $this->request->getFile('avatar');

        if ($avatar && $avatar->getError() !== UPLOAD_ERR_NO_FILE) {

            // Validate uploaded avatar
            $validation = [
                'avatar' => [
                    'label' => 'Avatar',
                    'rules' => 'uploaded[avatar]|is_image[avatar]|mime_in[avatar,image/jpeg,image/png]|max_size[avatar,2048]'
                ]
            ];

            if (!$this->validate($validation)) {
                return redirect()->back()
                    ->withInput()
                    ->with('errors', $this->validator->getErrors());
            }

            // Generate a unique filename
            $newName = $avatar->getRandomName();

            // Temporary location
            $tempPath = WRITEPATH . 'uploads/' . $newName;

            // Make sure the temporary folder exists
            if (!is_dir(WRITEPATH . 'uploads')) {
                mkdir(WRITEPATH . 'uploads', 0777, true);
            }

            // Move original upload to temporary location
            $avatar->move(
                WRITEPATH . 'uploads',
                $newName
            );

            // Final thumbnail location
            $finalPath = FCPATH . 'uploads/avatars/' . $newName;

            // Make sure the final folder exists
            if (!is_dir(FCPATH . 'uploads/avatars')) {
                mkdir(FCPATH . 'uploads/avatars', 0777, true);
            }

            /*
             * Prepare the image as a 300x300 display-ready thumbnail.
             */
            $image = service('image');

            $image->withFile($tempPath)
                ->fit(300, 300, 'center')
                ->save($finalPath, 80);

            // Remove temporary original
            if (is_file($tempPath)) {
                unlink($tempPath);
            }

            // Save ONLY the prepared filename in the database
            $data['avatar'] = $newName;

            // Delete previous avatar if one exists
            if (!empty($user['avatar'])) {

                $oldAvatar = FCPATH . 'uploads/avatars/' . $user['avatar'];

                if (is_file($oldAvatar)) {
                    unlink($oldAvatar);
                }
            }
        }

        $userModel->update($id, $data);

        return redirect()->to('/users');
    }
}