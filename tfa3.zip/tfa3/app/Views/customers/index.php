<!DOCTYPE html>
<html>
<head>
    <title>New Customer</title>
    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">
</head>
<body>

<header>
    <h1>New Customer</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('/customers') ?>">Customers</a>
        <a href="<?= base_url('/users') ?>">Users</a>
    </nav>
</header>

<div class="container">

    <div class="card">

        <h2>Add New Customer</h2>

        <?php if (session()->getFlashdata('errors')): ?>
            <div class="error">
                <ul>
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('/customers/create') ?>" method="post">

            <?= csrf_field() ?>

            <label for="full_name">Full Name</label>
            <input
                type="text"
                id="full_name"
                name="full_name"
                value="<?= old('full_name') ?>"
            >

            <br><br>

            <label for="email">Email</label>
            <input
                type="text"
                id="email"
                name="email"
                value="<?= old('email') ?>"
            >

            <br><br>

            <label for="phone">Phone</label>
            <input
                type="text"
                id="phone"
                name="phone"
                value="<?= old('phone') ?>"
            >

            <br><br>

            <button type="submit">Save Customer</button>

        </form>

    </div>

</div>

</body>
</html>