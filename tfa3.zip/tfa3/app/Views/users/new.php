<!DOCTYPE html>
<html>
<head>
    <title>New User</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">
</head>

<body>

<header>
    <h1>New User</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('/customers') ?>">Customers</a>
        <a href="<?= base_url('/users') ?>">Users</a>
        <a href="<?= base_url('/about') ?>">About</a>
    </nav>
</header>

<div class="container">

    <div class="card">

        <h2>Add New User</h2>

        <?php if (session()->getFlashdata('errors')): ?>

            <div class="error">

                <ul>

                    <?php foreach (session()->getFlashdata('errors') as $error): ?>

                        <li><?= esc($error) ?></li>

                    <?php endforeach; ?>

                </ul>

            </div>

        <?php endif; ?>


        <form action="<?= site_url('users/create') ?>" method="post">

            <?= csrf_field() ?>


            <label for="username">
                Username
            </label>

            <input
                type="text"
                id="username"
                name="username"
                value="<?= old('username') ?>"
            >


            <br><br>


            <label for="full_name">
                Full Name
            </label>

            <input
                type="text"
                id="full_name"
                name="full_name"
                value="<?= old('full_name') ?>"
            >


            <br><br>


            <label for="email">
                Email
            </label>

            <input
                type="text"
                id="email"
                name="email"
                value="<?= old('email') ?>"
            >


            <br><br>


            <button type="submit">
                Save User
            </button>

        </form>

    </div>

</div>

</body>
</html>