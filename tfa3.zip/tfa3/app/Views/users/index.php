<!DOCTYPE html>
<html>
<head>
    <title>Users</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">

    <style>
        .avatar {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 50%;
        }

        .avatar-placeholder {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: #ddd;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .edit-button {
            display: inline-block;
            padding: 8px 12px;
            background: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .edit-button:hover {
            background: #555;
        }
    </style>
</head>

<body>

<header>
    <h1>Users</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('/customers') ?>">Customers</a>
        <a href="<?= base_url('/users') ?>">Users</a>
        <a href="<?= base_url('/about') ?>">About</a>
    </nav>
</header>

<div class="container">

    <div class="card">

        <h2>User List</h2>

        <p>
            <a href="<?= site_url('users/new') ?>">
                Add New User
            </a>
        </p>

        <table>

            <thead>
                <tr>
                    <th>Avatar</th>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

                <?php if (!empty($users)): ?>

                    <?php foreach ($users as $user): ?>

                        <tr>

                            <td>

                                <?php if (!empty($user['avatar'])): ?>

                                    <img
                                        src="<?= base_url('uploads/avatars/' . $user['avatar']) ?>"
                                        alt="Avatar of <?= esc($user['full_name']) ?>"
                                        class="avatar"
                                    >

                                <?php else: ?>

                                    <div class="avatar-placeholder">
                                        👤
                                    </div>

                                <?php endif; ?>

                            </td>

                            <td>
                                <?= esc($user['username']) ?>
                            </td>

                            <td>
                                <?= esc($user['full_name']) ?>
                            </td>

                            <td>
                                <?= esc($user['email']) ?>
                            </td>

                            <td>
                                <a
                                    href="<?= site_url('users/edit/' . $user['id']) ?>"
                                    class="edit-button"
                                >
                                    Edit
                                </a>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="5">
                            No users found.
                        </td>
                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>