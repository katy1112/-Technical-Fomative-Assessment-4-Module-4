<!DOCTYPE html>
<html>
<head>
    <title>Login</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">
</head>

<body>

<header>
    <h1>POS System Login</h1>
</header>

<div class="container">

    <div class="card">

        <h2>Staff Login</h2>

        <?php if (session()->getFlashdata('error')): ?>

            <div class="error">
                <?= esc(session()->getFlashdata('error')) ?>
            </div>

        <?php endif; ?>

        <form action="<?= site_url('login') ?>" method="post">

            <?= csrf_field() ?>

            <label for="username">
                Username
            </label>

            <input
                type="text"
                id="username"
                name="username"
                value="<?= old('username') ?>"
            >

            <br><br>

            <label for="password">
                Password
            </label>

            <input
                type="password"
                id="password"
                name="password"
            >

            <br><br>

            <button type="submit">
                Login
            </button>

        </form>

    </div>

</div>

</body>
</html>