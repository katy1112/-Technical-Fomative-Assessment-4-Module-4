<!DOCTYPE html>
<html>
<head>
    <title>Database Test</title>
</head>
<body>

<h1>Database Connection Test</h1>

<h2>Customers</h2>

<?php foreach ($customers as $customer): ?>

    <p>
        <?= esc($customer['full_name']) ?> -
        <?= esc($customer['email']) ?> -
        <?= esc($customer['phone']) ?>
    </p>

<?php endforeach; ?>


<h2>Users</h2>

<?php foreach ($users as $user): ?>

    <p>
        <?= esc($user['username']) ?> -
        <?= esc($user['full_name']) ?> -
        <?= esc($user['role']) ?>
    </p>

<?php endforeach; ?>

</body>
</html>