<!DOCTYPE html>
<html>
<head>
    <title>Customer Accounts</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">
</head>

<body>

<header>
    <h1>About the POS System</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('/about') ?>">About</a>
        <a href="<?= base_url('/customers') ?>">Customers</a>
        <a href="<?= base_url('/users') ?>">Users</a>
    </nav>
</header>

<div class="container">

    <div class="card">
        <h2>About This Project</h2>

        <p>
            This is a basic Point-of-Sale system created using
            CodeIgniter 4 and the MVC architecture.
        </p>

        <br>

        <p>
            The system demonstrates routing, controllers, views,
            and the use of static PHP arrays for temporary data.
        </p>
    </div>

</div>

</body>
</html>