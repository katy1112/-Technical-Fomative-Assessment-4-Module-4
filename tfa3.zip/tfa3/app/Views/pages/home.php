<!DOCTYPE html>
<html>
<head>
    <title>Customer Accounts</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">
</head>
<body>

<header>

    <h1>Point-of-Sale System</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('/about') ?>">About</a>
        <a href="<?= base_url('/customers') ?>">Customers</a>
        <a href="<?= base_url('/users') ?>">Users</a>
    </nav>

</header>

<div class="container">

    <div class="card">

        <h2>Welcome 👋</h2>

        <p>
            Welcome to our Point-of-Sale System.
            This system provides simple access to customer
            and user account information.
        </p>

    </div>

    <div class="card">

        <h2>System Features</h2>

        <p>
            Manage and view customer accounts and user accounts
            through the navigation above.
        </p>

    </div>

</div>

</body>
</html>